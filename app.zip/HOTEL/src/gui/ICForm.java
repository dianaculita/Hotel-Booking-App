package gui;

import dao.InterogariComplexe;
import dao.InterogariSimple;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import javax.swing.DefaultListModel;

public class ICForm extends javax.swing.JFrame {

    private DefaultListModel<Vector<Object>> model1;
   
    private InterogariComplexe ic = new InterogariComplexe();
    
    //private static ICForm singleton;

    public ICForm() {
        initComponents();
        setVisible(true);
        setResizable(true);
        setLocationRelativeTo(null);

        model1 = new DefaultListModel<>();
        
        jButton15.addActionListener(ev -> interogareC1());
        jButton17.addActionListener(ev -> interogareC2());
        jButton18.addActionListener(ev -> interogareC3());
        jButton19.addActionListener(ev -> interogareC4());
    }
    
    /*public static ICForm getInstance(){
        if(singleton == null){
            singleton = new ICForm();
        }
        return singleton;
    }*/
    
    private void interogareC1(){
        model1.clear();
        jList2.setModel(model1);
        List<Vector<Object>> Rez = new LinkedList<>();
        Rez = ic.interogareC1();
        Vector<Object> vecObj = new Vector<>();
        for(Vector<Object> v : Rez){
            model1.addElement(v);
        }
    }
    
    private void interogareC2(){
        model1.clear();
        jList2.setModel(model1);
        List<Vector<Object>> Rez = new LinkedList<>();
        Rez = ic.interogareC2();
        Vector<Object> vecObj = new Vector<>();
        for(Vector<Object> v : Rez){
            model1.addElement(v);
        }
    }
    
    private void interogareC3(){
        model1.clear();
        jList2.setModel(model1);
        List<Vector<Object>> Rez = new LinkedList<>();
        Rez = ic.interogareC3();
        Vector<Object> vecObj = new Vector<>();
        for(Vector<Object> v : Rez){
            model1.addElement(v);
        }
    }
    
    private void interogareC4(){
        model1.clear();
        jList2.setModel(model1);
        List<Vector<Object>> Rez = new LinkedList<>();
        Rez = ic.interogareC4();
        Vector<Object> vecObj = new Vector<>();
        for(Vector<Object> v : Rez){
            model1.addElement(v);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton15 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton15.setBackground(new java.awt.Color(153, 255, 153));
        jButton15.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton15.setText("Go");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton17.setBackground(new java.awt.Color(153, 153, 255));
        jButton17.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton17.setText("Go");

        jButton18.setBackground(new java.awt.Color(0, 153, 204));
        jButton18.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton18.setText("Go");

        jButton19.setBackground(new java.awt.Color(255, 204, 204));
        jButton19.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton19.setText("Go");

        jList2.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jScrollPane2.setViewportView(jList2);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("Pentru fiecare cerere sa se determine numele, prenumele, cnp-ul si varsta persoanei cele mai tinere ce are o asigurare medicala valabila 2 zile. ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel2.setText("Afisati prima luna din anul 2019 in care s-au inregistrat mai multe cereri decat media inregistrata in acest an, cu numarul cererilor respective");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel3.setText("Determinati numele, prenumele si valabilitatea asigurarii medicale pentru clientii (ordonati alfabetic) au o asigurare medicala de o valabilitate mai indelungata");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel4.setText("decat celelalte persoane care apartin de aceeasi cerere de cazare ");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel5.setText("Rezultatul se sorteaza descrescator dupa varsta");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel6.setText("Afisati alfabetic numele si prenumele clientilor impreuna cu codul cererii pentru cererea rezervata are un numar de camere egal cu cel minim dintre toate cererile ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(46, 46, 46)
                        .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(42, 42, 42)
                        .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2))
                .addContainerGap(572, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(58, 58, 58)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JList<Vector<Object>> jList2;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

}
