package gui;

import dao.AsigurareDAO;
import dao.CameraDAO;
import dao.CerereDAO;
import dao.ClientDAO;
import dao.FacilitatiCameraDAO;
import dao.FacilitatiDAO;
import dao.InterogariComplexe;
import dao.InterogariSimple;
import dao.PersoanaDAO;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import models.AsigurareMedicala;
import models.Camera;
import models.CerereCazare;
import models.Client;
import models.Facilitate;
import models.FacilitatiCamera;
import models.Persoana;

public class HotelForm extends javax.swing.JFrame {
    private static HotelForm singleton;
    
    private DefaultListModel<Object> model;
    private DefaultListModel<Vector<Object>> model1;
    
    private InterogariSimple is = new InterogariSimple();
    private InterogariComplexe ic = new InterogariComplexe();
    
    private HotelForm() {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        
        model = new DefaultListModel<>();
        model1 = new DefaultListModel<>();
        
        jButton7.addActionListener(ev -> afisareCereri());
        jButton8.addActionListener(ev -> afisareClienti());
        jButton9.addActionListener(ev -> afisarePersoane());
        jButton10.addActionListener(ev -> afisareAsigurari());
        jButton11.addActionListener(ev -> afisareCamere());
        jButton12.addActionListener(ev -> afisareFacilitati());
        jButton13.addActionListener(ev -> afisareFacilitatiCamera());
        
        jButton20.addActionListener(ev -> interogariSimple());
        jButton21.addActionListener(ev -> interogariComplexe());
        jButton1.addActionListener(ev -> addDate());
        jButton14.addActionListener(ev -> sterge());
    }
    
    private void interogariSimple(){
        //ISForm.getInstance();
        new ISForm();
    }
    
    private void interogariComplexe(){
        //ICForm.getInstance();
        new ICForm();
    }
    
    private void addDate(){
        new CerereForm();
    }
    
    private void afisareCereri(){
        model.clear();
        CerereDAO C = new CerereDAO();
        jList1.setModel(model);
        List<CerereCazare> cereri = new LinkedList<>();
        cereri = C.getCereri();
        for(CerereCazare c : cereri){
            model.addElement(c);
        }
    }
    
    private void afisareClienti(){
        model.clear();
        ClientDAO C = new ClientDAO();
        jList1.setModel(model);
        List<Client> clienti = new LinkedList<>();
        clienti = C.getClienti();
        for(Client c : clienti){
            model.addElement(c);
        }
    }
    
    private void afisarePersoane(){
        model.clear();
        PersoanaDAO P = new PersoanaDAO();
        jList1.setModel(model);
        List<Persoana> prs = new LinkedList<>();
        prs = P.getPersoane();
        for(Persoana p : prs){
            model.addElement(p);
        }
    }
    
    private void afisareAsigurari(){
        model.clear();
        AsigurareDAO A = new AsigurareDAO();
        jList1.setModel(model);
        List<AsigurareMedicala> asg = new LinkedList<>();
        asg = A.getAsigurari();
        for(AsigurareMedicala a : asg){
            model.addElement(a);
        }
    }
    
    private void afisareCamere(){
        model.clear();
        CameraDAO C = new CameraDAO();
        jList1.setModel(model);
        List<Camera> cam = new LinkedList<>();
        cam = C.getCamere();
        for(Camera c : cam){
            model.addElement(c);
        }
    }
    
    private void afisareFacilitati(){
        model.clear();
        FacilitatiDAO F = new FacilitatiDAO();
        jList1.setModel(model);
        List<Facilitate> fac = new LinkedList<>();
        fac = F.getFacilitati();
        for(Facilitate f : fac){
            model.addElement(f);
        }
    }
    
    private void afisareFacilitatiCamera(){
        model.clear();
        FacilitatiCameraDAO F = new FacilitatiCameraDAO();
        jList1.setModel(model);
        List<FacilitatiCamera> fac = new LinkedList<>();
        fac = F.getFacilitatiCamera();
        for(FacilitatiCamera f : fac){
            model.addElement(f);
        }
    }
    
    private void sterge(){
        CerereDAO cerere = new CerereDAO();
        ClientDAO client = new ClientDAO();
        CameraDAO camera = new CameraDAO();
        PersoanaDAO persoana = new PersoanaDAO();
        FacilitatiDAO facilitati = new FacilitatiDAO();
        AsigurareDAO asig = new AsigurareDAO();
        FacilitatiCameraDAO fcam = new FacilitatiCameraDAO();
        
        cerere.deleteAll();
        client.deleteAll();
        camera.deleteAll();
        persoana.deleteAll();
        facilitati.deleteAll();
        asig.deleteAll();
        fcam.deleteAll();
        
        JOptionPane.showMessageDialog(this,"Baza de date golita!");
    }

    
    
    public static HotelForm getInstance(){
        if(singleton == null){
            singleton = new HotelForm();
        }
        return singleton;
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton16 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jButton16.setText("jButton16");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("Afisare inregistrari din tabela:");

        jList1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jScrollPane1.setViewportView(jList1);

        jButton7.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton7.setText("Cereri cazare");

        jButton8.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton8.setText("Clienti");

        jButton9.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton9.setText("Persoane");

        jButton10.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton10.setText("Asigurari medicale");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton11.setText("Camere");

        jButton12.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton12.setText("Facilitati");

        jButton13.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton13.setText("Facilitati camera");

        jButton14.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton14.setText("GOLIRE BAZA DE DATE");

        jButton20.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton20.setText("INTEROGARI SIMPLE");

        jButton21.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton21.setText("INTEROGARI COMPLEXE");

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton1.setText("ADAUGARE CERERE CAZARE");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1714, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(87, 87, 87))
            .addGroup(layout.createSequentialGroup()
                .addGap(1139, 1139, 1139)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addGap(56, 56, 56)
                        .addComponent(jButton8)
                        .addGap(62, 62, 62)
                        .addComponent(jButton9)
                        .addGap(80, 80, 80)
                        .addComponent(jButton10))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton11)
                        .addGap(65, 65, 65)
                        .addComponent(jButton12)
                        .addGap(66, 66, 66)
                        .addComponent(jButton13)))
                .addGap(86, 86, 86)
                .addComponent(jButton1)
                .addGap(77, 77, 77)
                .addComponent(jButton14)
                .addGap(78, 78, 78)
                .addComponent(jButton20)
                .addGap(52, 52, 52)
                .addComponent(jButton21)
                .addContainerGap(398, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<Object> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
