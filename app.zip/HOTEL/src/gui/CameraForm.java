package gui;

import dao.CameraDAO;
import dao.FacilitatiCameraDAO;
import dao.FacilitatiDAO;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;
import models.Camera;
import models.Client;
import models.Facilitate;
import models.FacilitatiCamera;
import models.Hotel;
import models.Persoana;

public class CameraForm extends javax.swing.JFrame {
    private FacilitatiDAO facil;
    private CameraDAO cam;
    private FacilitatiCameraDAO fcam;
    
    public CameraForm() {
        initComponents();
        
        setVisible(true);
        setLocationRelativeTo(null);
        
       jButton1.addActionListener(ev -> addCamera());
    }
    
    private void stergeFacilitatile(){
        FacilitatiDAO fac = new FacilitatiDAO();
        fac.deleteAll();
    }
    
    private void addCamera(){
        Camera c = new Camera();
        cam = new CameraDAO();
        facil = new FacilitatiDAO();
        fcam = new FacilitatiCameraDAO();
        
        boolean cam1 = jCheckBox14.isSelected();
        boolean cam2 = jCheckBox13.isSelected();
        boolean cam3 = jCheckBox1.isSelected();
        boolean ap = jCheckBox2.isSelected();
        boolean balcon = jCheckBox3.isSelected();
        boolean wifi = jCheckBox4.isSelected();
        boolean aer = jCheckBox5.isSelected();
        boolean masa1 = jCheckBox6.isSelected();
        boolean masa2 = jCheckBox11.isSelected();
        boolean masa3 = jCheckBox7.isSelected();
        boolean buc = jCheckBox8.isSelected();
        boolean bai2 = jCheckBox9.isSelected();
        boolean paturiSg = jCheckBox10.isSelected();
        boolean curat = jCheckBox12.isSelected();
        
        String tip = "";
        int nrpers = 0;
        if(cam1){
            tip = "single";
            nrpers = 1;
        }
        if(cam2){
            tip = "dubla";
            nrpers = 2;
        }
        if(cam3){
            tip = "tripla";
            nrpers = 3;
        }
        if(ap){
            tip = "apartament";
            nrpers = 4;
        }
        
        Facilitate f1;
        List<Facilitate> f = new LinkedList();
        
        if(balcon){
            f1 = new Facilitate(1);
            f.add(f1);
        }
        if(wifi){
            f1 = new Facilitate(2);
            f.add(f1);
        }
        if(aer){
            f1 = new Facilitate(3);
            f.add(f1);
        }
        if(masa1){
            f1 = new Facilitate(4);
            f.add(f1);
        }
        if(masa2){
            f1 = new Facilitate(5);
            f.add(f1);
        }
        if(masa3){
            f1 = new Facilitate(6);
            f.add(f1);
        }
        if(buc){
            f1 = new Facilitate(7);
            f.add(f1);
        }
        if(bai2){
            f1 = new Facilitate(8);
            f.add(f1);
        }
        if(paturiSg){
            f1 = new Facilitate(9);
            f.add(f1);
        }
        if(curat){
            f1 = new Facilitate(10);
            f.add(f1);
        }

        FacilitatiCamera fc = new FacilitatiCamera();
        fc.setF(f);
        c.setFacilitati(fc);
        c.setTip(tip);
        c.setPret();
        
        fcam.addFacilitate(0);
        
        int codcrr = Hotel.getInstance().getLastCerere().getCod();
        cam.addCamera(tip, c.getPret(), codcrr, nrpers, 0); 
        
        int nrCam = cam.getLastRoomNr();
        fcam.updateNrCam(nrCam);
        
        int id = fcam.getLastIDFacilitati();
        cam.updateID(id);
        
        int cost = c.getPret();
        cam.updateCost(cost);
        
        if(balcon){
            facil.addFacilitati("balcon", 5, id);
        }
        if(wifi){
            facil.addFacilitati("wifi", 5, id);
        }
        if(aer){
            facil.addFacilitati("aer conditionat", 0, id);
        }
        if(masa1){
            facil.addFacilitati("o masa inclusa", 25, id);
        }
        if(masa2){
            facil.addFacilitati("doua mese incluse", 45, id);
        }
        if(masa3){
            facil.addFacilitati("trei mese incluse", 70, id);
        }
        if(buc){
            facil.addFacilitati("bucatarie", 10, id);
        }
        if(bai2){
            facil.addFacilitati("doua bai", 0, id);
        }
        if(paturiSg){
            facil.addFacilitati("paturi single", 0, id);
        }
        if(curat){
            facil.addFacilitati("curatenie zilnica", 10, id);
        }
        
        
        //Client client = Hotel.getInstance().getLastCerere().getClient();
        //client.setNrCam(nrCam);
        cam.updateNrCameraClient(nrCam);
        
        if(nrpers >= 1){
            //Persoana ultimaPers = Hotel.getInstance().getLastCerere().getLastPers();
            //ultimaPers.setNrCamera(nrCam);
            cam.updateNrCameraPers(nrCam);
        }
        
        System.out.println("CAMERA FORM");
        System.out.println("camera adaugata: " + c);
        System.out.println("grup facilitati: " + f);

        JOptionPane.showMessageDialog(this, "Camera cu facilitati adaugata!");
        
        setVisible(false);
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jCheckBox13 = new javax.swing.JCheckBox();
        jCheckBox14 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel3.setText("Tip");

        jCheckBox1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox1.setText("Camera tripla");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox2.setText("Apartament");

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jCheckBox3.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox3.setText("Balcon");

        jCheckBox4.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox4.setText("WIFI");

        jCheckBox5.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox5.setText("Aer conditionat");

        jCheckBox6.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox6.setText("O masa inclusa");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel6.setText("Facilitati");

        jCheckBox7.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox7.setText("Trei mese incluse");

        jCheckBox8.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox8.setText("Bucatarie");

        jCheckBox9.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox9.setText("Doua bai");

        jCheckBox10.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox10.setText("Paturi single");

        jCheckBox11.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox11.setText("Doua mase incluse");

        jCheckBox12.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox12.setText("Curatenie zilnica");

        jCheckBox13.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox13.setText("Camera dubla");
        jCheckBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox13ActionPerformed(evt);
            }
        });

        jCheckBox14.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jCheckBox14.setText("Camera single");
        jCheckBox14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel3)
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox13)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox14)
                    .addComponent(jCheckBox2))
                .addGap(258, 258, 258)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox12)
                            .addComponent(jCheckBox10)
                            .addComponent(jCheckBox9)
                            .addComponent(jCheckBox7)
                            .addComponent(jLabel6)
                            .addComponent(jCheckBox4)
                            .addComponent(jCheckBox3)
                            .addComponent(jCheckBox6)
                            .addComponent(jCheckBox5))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jCheckBox11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(93, 93, 93))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jCheckBox8)
                        .addGap(59, 676, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jCheckBox3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBox11)
                            .addComponent(jButton1))
                        .addGap(29, 29, 29)
                        .addComponent(jCheckBox7)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckBox8)
                        .addGap(33, 33, 33)
                        .addComponent(jCheckBox9)
                        .addGap(40, 40, 40)
                        .addComponent(jCheckBox10)
                        .addGap(35, 35, 35)
                        .addComponent(jCheckBox12))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jCheckBox14))
                        .addGap(26, 26, 26)
                        .addComponent(jCheckBox13)
                        .addGap(18, 18, 18)
                        .addComponent(jCheckBox1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox2)))
                .addContainerGap(79, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox13ActionPerformed

    private void jCheckBox14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox14ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox14;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
