package models;

import java.time.LocalDate;
import java.time.LocalTime;

public class AsigurareMedicala{
    private int cod;
    private LocalDate dataEliberarii;
    private LocalDate valabilitate;
    private String clauze;
    private String cnp;
    private String nume, prenume;
    //private Persoana pers;

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    
    
    public String getCnp() {
        return cnp;
    }

    public void setCnp(String cnp) {
        this.cnp = cnp;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public LocalDate getDataEliberarii() {
        return dataEliberarii;
    }

    public void setDataEliberarii(LocalDate dataEliberarii) {
        this.dataEliberarii = dataEliberarii;
    }

    public LocalDate getValabilitate() {
        return valabilitate;
    }

    public void setValabilitate(LocalDate valabilitate) {
        this.valabilitate = valabilitate;
    }
    
    public String getClauze() {
        return clauze;
    }

    public void setClauze(String clauze) {
        this.clauze = clauze;
    }

    @Override
    public String toString() {
        return "AsigurareMedicala{" + "cod=" + cod + ", dataEliberarii=" + dataEliberarii + ", valabilitate=" + valabilitate + ", clauze=" + clauze + ", cnp=" + cnp + ", nume=" + nume + ", prenume=" + prenume + '}';
    }

    
    
    
}
