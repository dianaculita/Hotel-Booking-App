package models;

import java.util.List;

public class Camera {
    private int nr;
    private int etaj;
    private String tip;
    private int nrPers;
    private int codCerere;
    private int pret;
    
    private List<Persoana> persoane;
    private FacilitatiCamera facilitati;

    public FacilitatiCamera getFacilitati() {
        return facilitati;
    }

    public void setFacilitati(FacilitatiCamera facilitati) {
        this.facilitati = facilitati;
    }
    
    public void setPret() {
        this.pret = 0;
        if(this.tip.equals("single")){
            this.pret += 175;
        }
        if(this.tip.equals("dubla")){
            this.pret += 220;
        }
        if(this.tip.equals("tripla")){
            this.pret += 280;
        }
        if(this.tip.equals("apartament")){
            this.pret += 350;
        }
        
        pret += facilitati.getCostExtra();
    }
    
    public int getPret(){
        return this.pret;
    }

    public void setPret(int pret) {
        this.pret = pret;
    }
    
    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public int getEtaj() {
        return etaj;
    }

    public void setEtaj(int etaj) {
        this.etaj = etaj;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public int getNrPers() {
        return nrPers;
    }

    public void setNrPers(int nrPers) {
        this.nrPers = nrPers;
    }

    public int getCodCerere() {
        return codCerere;
    }

    public void setCodCerere(int codCerere) {
        this.codCerere = codCerere;
    }

    public List<Persoana> getPersoane() {
        return persoane;
    }

    public void setPersoane(List<Persoana> persoane) {
        this.persoane = persoane;
    }

    @Override
    public String toString() {
        return "Camera{" + "nr=" + nr + ", tip=" + tip + ", nrPers=" + nrPers + ", pret=" + pret;
    }
    
    

}
