package models;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class CerereCazare {
    private int cod;
    private int nrPersoane;
    private int costTotal; //costul total al cererii : toate camerele + facilitatile
    private LocalDate checkin, checkout;
    private String alteDetalii;
    private String metodaPlata;
    private int nrCamere;
    
    private Client c;
    private List<Persoana> persoane;
    private List<Camera> camere;
    
    public Persoana getLastPers(){
        Persoana p = new Persoana();
        if(nrPersoane >= 1){
            p = persoane.get(persoane.size()-1);
        }
        return p;
    }
    
    public int getCod(){
        return this.cod;
    }

    public void setCostTotal(int costTotal) {
        this.costTotal = costTotal;
    }
    
    

    public void setCod(int cod){
        this.cod = cod;
    }
            
    public LocalDate getCheckin() {
        return checkin;
    }
    
    public void addClient(Client c){
        this.c = c;
    }
    
    public Client getClient(){
        return this.c;
    }
    
    public void setClient(Client c){
        this.c = c;
    }
    
    public void setCheckin(LocalDate checkin) {
        this.checkin = checkin;
    }

    public LocalDate getCheckout() {
        return checkout;
    }

    public void setCheckout(LocalDate checkout) {
        this.checkout = checkout;
    }

    public List<Persoana> adaugaPers(Persoana p){
        persoane = new LinkedList<>();
        persoane.add(p);
        return persoane;
    }
    
    public List<Camera> adaugaCamera(Camera c){
        camere = new LinkedList<>();
        camere.add(c);
        return camere;
    }

    public int getNrPersoane() {
        return nrPersoane;
    }

    public void setNrPersoane(int nrPersoane) {
        this.nrPersoane = nrPersoane;
    }

    public int getCostTotal() {
        
        return costTotal;
    }
    
    public void setCostTotal(){
        this.costTotal = 0;
        for(Camera c : camere){ // adun costurile de la toate camerele
            this.costTotal += c.getPret();  
        }
    }

    public String getAlteDetalii() {
        return alteDetalii;
    }

    public void setAlteDetalii(String alteDetalii) {
        this.alteDetalii = alteDetalii;
    }

    public String getMetodaPlata() {
        return metodaPlata;
    }

    public void setMetodaPlata(String metodaPlata) {
        this.metodaPlata = metodaPlata;
    }

    public int getNrCamere() {
        return nrCamere;
    }

    public void setNrCamere(int nrCamere) {
        this.nrCamere = nrCamere;
    }

    public List<Persoana> getPersoane() {
        return persoane;
    }

    public void setPersoane(List<Persoana> persoane) {
        this.persoane = persoane;
    }

    @Override
    public String toString() {
        return "CerereCazare{" + "cod=" + cod + ", nrPersoane=" + nrPersoane + ", costTotal=" + costTotal + ", checkin=" + checkin + ", checkout=" + checkout + ", alteDetalii=" + alteDetalii + ", metodaPlata=" + metodaPlata + ", nrCamere=" + nrCamere;
    }

   
}
