package models;

import java.util.List;

public class FacilitatiCamera {
    private int numarCamera;
    private int id;
    private List<Facilitate> f;

    public void setId(int id) {
        this.id = id;
    }
    
    
    
    public int getCostExtra(){
        int suma = f.stream().mapToInt(f -> f.getCostExtra()).sum();
        return suma;
    }
    
    public List<Facilitate> getF() {
        return f;
    }

    public void setF(List<Facilitate> f) {
        this.f = f;
    }

    public int getNumarCamera() {
        return numarCamera;
    }

    public void setNumarCamera(int numarCamera) {
        this.numarCamera = numarCamera;
    } 

    @Override
    public String toString() {
        return "FacilitatiCamera{" + "numarCamera=" + numarCamera + ", id=" + id;
    }
 
}
