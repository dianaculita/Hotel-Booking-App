package models;

import java.time.LocalDate;

public class Persoana {
    private String nume;
    private String prenume;
    private String CNP;
    private LocalDate dataNasterii;
    private char sex;
    private int codCerere;
    
    private AsigurareMedicala asig;
    private int nrCamera;
    
    public Persoana getPersByCNP(String cnp){
        Persoana p = new Persoana();
        if(this.CNP.equals(cnp)){
            p = this;
        }
        return p;
    }

    public int getCodCerere() {
        return codCerere;
    }

    public void setCodCerere(int codCerere) {
        this.codCerere = codCerere;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public String getCNP() {
        return CNP;
    }

    public void setCNP(String CNP) {
        this.CNP = CNP;
    }

    public LocalDate getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(LocalDate dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public AsigurareMedicala getAsig() {
        return asig;
    }

    public void setAsig(AsigurareMedicala asig) {
        this.asig = asig;
    }

    public int getNrCamera() {
        return nrCamera;
    }

    public void setNrCamera(int nrCamera) {
        this.nrCamera = nrCamera;
    }

    @Override
    public String toString() {
        return "Persoana{" + "nume=" + nume + ", prenume=" + prenume + ", CNP=" + CNP + ", dataNasterii=" + dataNasterii + ", sex=" + sex + ", codCerere=" + codCerere + ", nrCamera=" + nrCamera + '}';
    }

    

    
      
}
