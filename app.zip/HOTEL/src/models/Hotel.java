package models;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Hotel {
    private List<CerereCazare> cereri = new LinkedList<>();
    private static Hotel singleton;
    
    private Hotel(){
    }
    
    public CerereCazare getLastCerere(){
        return cereri.get(cereri.size()-1); //-1
    }

    public void addCerere(CerereCazare c){
        cereri.add(c);
    }
    
    public static Hotel getInstance(){
        if(singleton == null){
            singleton = new Hotel();
        }
        return singleton;
    }
    
    public List<CerereCazare> getCereri(){
        return cereri;
    }
    
}
