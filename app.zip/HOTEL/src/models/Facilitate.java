package models;

import java.util.List;

public class Facilitate {
    private int cod;
    private String denumire;
    private int costExtra;
    private int idFacilCam;

    public int getIdFacilCam() {
        return idFacilCam;
    }

    public void setIdFacilCam(int idFacilCam) {
        this.idFacilCam = idFacilCam;
    }
    
    
    
    public Facilitate(int cod){
        this.cod = cod;
    }
    
    public Facilitate(){
        this.cod = 0;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public void setCostExtra(int costExtra) {
        this.costExtra = costExtra;
    }
    
    
    
    public String getDenumire(){
        this.denumire = "";
        if(this.cod == 1){
            this.denumire = "balcon";
        }
        if(this.cod == 2){
            this.denumire = "wifi";
        }
        if(this.cod == 3){
            this.denumire = "aer conditionat";
        }
        if(this.cod == 4){
            this.denumire = "o masa inclusa";
        }
        if(this.cod == 5){
            this.denumire = "doua mese incluse";
        }
        if(this.cod == 6){
            this.denumire = "trei mese incluse";
        }
        if(this.cod == 7){
            this.denumire = "bucatarie";
        }
        if(this.cod == 8){
            this.denumire = "doua bai";
        }
        if(this.cod == 9){
            this.denumire = "paturi single";
        }
        if(this.cod == 10){
            this.denumire = "curatenie zilnica";
        }
        return this.denumire;
    }
    
    public int getCostExtra(){
        this.costExtra = 0;
        if(this.cod == 1){
            this.costExtra += 5;
        }      
        if(this.cod == 2){
            this.costExtra += 5;
        }
        if(this.cod == 4){
            this.costExtra += 25;
        }
        if(this.cod == 5){
            this.costExtra += 45;
        }
        if(this.cod == 6){
            this.costExtra += 70;
        }
        if(this.cod == 7){
            this.costExtra += 10;
        }
        if(this.cod == 10){
            this.costExtra += 10;
        }
        
        return this.costExtra;        
    }

   public int getCod(){
       return this.cod;
   }

    @Override
    public String toString() {
        return "Facilitate{" + "cod=" + cod + ", denumire=" + denumire + ", costExtra=" + costExtra + '}';
    }
    
}
