package models;

import java.time.LocalDate;
import java.util.List;

public class Client {
    private String nume;
    private String prenume;
    private String CNP;
    private LocalDate dataNasterii;
    private String semnatura;
    private String adresa;
    private char sex;
    private int nrCam;
    
    private AsigurareMedicala asig;
    private int codCerere;

    public int getNrCam() {
        return nrCam;
    }

    public void setNrCam(int nrCam) {
        this.nrCam = nrCam;
    }

    public int getCodCerere() {
        return codCerere;
    }

    public void setCodCerere(int codCerere) {
        this.codCerere = codCerere;
    }
    
    private List<Camera> camere;
    
    public void addToCerere(CerereCazare c){
        c.setClient(this);
    }

    public LocalDate getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(LocalDate dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public String getCNP() {
        return CNP;
    }

    public void setCNP(String CNP) {
        this.CNP = CNP;
    }

    public String getSemnatura() {
        return semnatura;
    }

    public void setSemnatura(String semnatura) {
        this.semnatura = semnatura;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public AsigurareMedicala getAsig() {
        return asig;
    }

    public void setAsig(AsigurareMedicala asig) {
        this.asig = asig;
    }

    public List<Camera> getCamere() {
        return camere;
    }

    public void setCamere(List<Camera> camere) {
        this.camere = camere;
    }
    
    public int getCodCerere(CerereCazare cerere){
        return cerere.getCod();
    }

    @Override
    public String toString() {
        return "Client{" + "nume=" + nume + ", prenume=" + prenume + ", CNP=" + CNP + ", dataNasterii=" + dataNasterii + ", semnatura=" + semnatura + ", adresa=" + adresa + ", sex=" + sex + ", nrCam=" + nrCam + '}';
    }

    
           
}
