package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class InterogariComplexe {
    private Connection conex;
    
    public InterogariComplexe(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    // Pentru fiecare cerere sa se determine numele, prenumele, cnp-ul si varsta
    // persoanei cele mai tinere ce are o asigurare medicala valabila 2 zile.
    // Rezultatul se sorteaza descrescator dupa varsta
    public List<Vector<Object>> interogareC1(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT P.CodCerere, P.Nume, P.Prenume, P.CNP, 2019-YEAR(P.DataNasterii) AS Varsta "
                + "FROM persoane AS P, asigurari AS A "
                + "WHERE P.CodAsigurare=A.CodAsigurare AND (DAY(A.Valabilitate)-DAY(A.DataEliberarii))=2 AND P.DataNasterii=(SELECT MAX(Pp.DataNasterii) FROM persoane AS Pp WHERE P.CodCerere=Pp.CodCerere) "
                + "ORDER BY Varsta DESC";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(5);
                vec.add(res.getInt(1));
                vec.add(res.getString(2));
                vec.add(res.getString(3));
                vec.add(res.getString(4));
                vec.add(res.getInt(5));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Afisati prima luna din anul 2019 in care s-au inregistrat mai multe cereri decat media inregistrata in acest an,
    // impreuna cu numarul cererilor respective.
    public List<Vector<Object>> interogareC2(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT MONTH(Checkin), COUNT(CodCerere) "
                + "FROM cerericazare "
                + "WHERE YEAR(Checkin)=2019 "
                + "GROUP BY MONTH(Checkin) "
                + "HAVING COUNT(CodCerere)>(SELECT AVG(tab.nrCereri) FROM (SELECT COUNT(CodCerere) AS nrCereri FROM cerericazare GROUP BY MONTH(Checkin)) AS tab) ";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(2);
                vec.add(res.getInt(1));
                vec.add(res.getInt(2));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Determinati numele, prenumele si valabilitatea asigurarii medicale pentru clientii (ordonati alfabetic)
    // care au o asigurare medicala de o valabilitate mai indelungata decat celelalte persoane care apartin 
    // de aceeasi cerere de cazare
    public List<Vector<Object>> interogareC3(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cl.Nume, Cl.Prenume, A.Valabilitate "
                + "FROM clienti AS Cl, asigurari AS A, cerericazare AS C "
                + "WHERE Cl.CodAsigurare=A.CodAsigurare AND Cl.CodCerere=C.CodCerere AND "
                + "A.Valabilitate>(SELECT MAX(tab.valab) FROM (SELECT Asig.Valabilitate AS valab, Cc.CodCerere AS cod FROM asigurari AS Asig, persoane AS Pers, cerericazare AS Cc WHERE Pers.CodAsigurare=Asig.CodAsigurare AND Pers.CodCerere=Cc.CodCerere GROUP BY Cc.CodCerere) AS tab WHERE C.CodCerere=tab.cod) "
                + "GROUP BY C.CodCerere "
                + "ORDER BY Cl.Nume, Cl.Prenume ";

        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getString(1));
                vec.add(res.getString(2));
                vec.add(res.getDate(3).toLocalDate());
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Afisati alfabetic numele si prenumele clientilor impreuna cu codul cererii pentru
    // care cererea rezervata are un numar de camere egal cu cel minim dintre toate cererile
    public List<Vector<Object>> interogareC4(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cl.Nume, Cl.Prenume, Cc.CodCerere "
                + "FROM cerericazare AS Cc, clienti AS Cl, (SELECT MIN(C.NumarCamere) AS minim "
                + "FROM cerericazare AS C) AS tabMinime "
                + "WHERE Cl.CodCerere=Cc.CodCerere AND Cc.NumarCamere=tabMinime.minim "
                + "ORDER BY Cl.Nume, Cl.Prenume";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getString(1));
                vec.add(res.getString(2));
                vec.add(res.getInt(3));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
}
