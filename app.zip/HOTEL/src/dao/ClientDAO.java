package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import models.Client;

public class ClientDAO {
    private Connection conex;
    public ClientDAO(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addClient(String n, String p, String cnp, LocalDate datan, String smn, String adr, char sex, int codasig, int nrcam, int codcerere){
        String cmmd = "INSERT INTO clienti VALUES(?,?,?,?,?,?,?,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            java.sql.Date dataN = java.sql.Date.valueOf(datan);
            
            ps.setString(1, cnp);
            ps.setString(2, n);
            ps.setString(3, p);
            ps.setDate(4, dataN);
            ps.setString(5, adr);
            ps.setString(6, String.valueOf(sex));
            ps.setString(7, smn);            
            ps.setInt(8, codasig);
            ps.setInt(9, nrcam);
            ps.setInt(10, codcerere);
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<Client> getClienti(){
        String cmmd = "SELECT * FROM Clienti";
        List<Client> clienti = new LinkedList<>();
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Client cl = new Client();
                cl.setNume(res.getString("Nume"));
                cl.setPrenume(res.getString("Prenume"));
                cl.setCNP(res.getString("CNP"));
                cl.setDataNasterii(res.getDate("DataNasterii").toLocalDate());
                cl.setSemnatura(res.getString("Semnatura"));
                cl.setSex(res.getString("Sex").charAt(0));
                cl.setCodCerere(res.getInt("CodCerere"));
                cl.setNrCam(res.getInt("NumarCamera"));
                cl.setAdresa(res.getString("Adresa"));

                clienti.add(cl);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return clienti;
    }
    
    public void deleteAll(){
        String cmmd = "DELETE FROM clienti";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

