package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import models.Facilitate;

public class FacilitatiDAO {
    private Connection conex;
    public FacilitatiDAO(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addFacilitati(String nume, int costExtra, int id){
        String cmmd = "INSERT INTO facilitati VALUES(NULL,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            
            ps.setString(1, nume);
            ps.setInt(2, costExtra);
            ps.setInt(3, id);
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
  
    public void deleteAll(){
        String cmmd = "DELETE FROM facilitati";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<Facilitate> getFacilitati(){
        List<Facilitate> facilitati = new LinkedList<>();
        String cmmd = "SELECT * FROM facilitati";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Facilitate f = new Facilitate();
                f.setCod(res.getInt("Cod"));
                f.setDenumire(res.getString("Denumire"));
                f.setCostExtra(res.getInt("CostExtra"));
                f.setIdFacilCam(res.getInt("IDFacilCam"));
                
                facilitati.add(f);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return facilitati;
        
    }
    
}
