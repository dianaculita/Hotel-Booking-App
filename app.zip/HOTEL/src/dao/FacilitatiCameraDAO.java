package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import models.FacilitatiCamera;

public class FacilitatiCameraDAO {
    private Connection conex;
    public FacilitatiCameraDAO(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addFacilitate(int nrcam){
        String cmmd = "INSERT INTO facilitaticamera VALUES(NULL,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){            
            ps.setInt(1, nrcam);

            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void updateNrCam(int nr){
        String cmmd = "UPDATE facilitaticamera SET NumarCamera=? WHERE NumarCamera=0";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){            
            ps.setInt(1, nr);

            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public int getLastIDFacilitati(){
        String cmmd = "SELECT IDFacilCam FROM facilitaticamera WHERE IDFacilCam=(SELECT MAX(IDFacilCam) FROM facilitaticamera);";
        List<Integer> iduri = new LinkedList<>();
        
        int i = 0;
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                i = res.getInt("IDFacilCam");
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return i;
    }

    public void deleteAll(){
        String cmmd = "DELETE FROM facilitaticamera";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<FacilitatiCamera> getFacilitatiCamera(){
        List<FacilitatiCamera> fcam = new LinkedList<>();
        String cmmd = "SELECT * FROM facilitaticamera";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                FacilitatiCamera f = new FacilitatiCamera();
                f.setNumarCamera(res.getInt("NumarCamera"));
                f.setId(res.getInt("IDFacilCam"));
                
                fcam.add(f);    
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return fcam;
    }
    
}

