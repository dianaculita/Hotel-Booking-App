package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class InterogariSimple {
    private Connection conex;
    public InterogariSimple(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    // Numele, prenumele si codul cererii pentru clientii care au o rezervare 
    // cu costul total de minim 260 si au rezervarea facuta pe 3 zile in aceeasi luna
    public List<Vector<Object>> interogareS1(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cl.Nume, Cl.Prenume, Cc.CodCerere "
                + "FROM cerericazare AS Cc, clienti AS Cl "
                + "WHERE Cc.CNP=Cl.CNP AND Cc.CostTotal>=260 AND (DAY(Cc.Checkout)-DAY(Cc.Checkin))=3";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getString(1));
                vec.add(res.getString(2));
                vec.add(res.getInt(3));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    
    // Numele, prenumele si valabilitatea asigurarii medicale pentru clientii cazati in ziua de 3 a lunii 
    // care stau la o camera single, ordonati descrescator dupa costul cazarii
    public List<Vector<Object>> interogareS2(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cc.CostTotal, Cl.Nume, Cl.Prenume, A.Valabilitate "
                + "FROM clienti AS Cl, cerericazare AS Cc, camere AS Ca, asigurari AS A "
                + "WHERE Cl.CodCerere=Cc.CodCerere AND Cl.CodAsigurare=A.CodAsigurare AND Cl.NumarCamera=Ca.NumarCamera AND DAY(Cc.Checkin)=3 AND Ca.Tip LIKE 'single' "
                + "ORDER BY Cc.CostTotal DESC";
                
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(4);
                vec.add(res.getInt(1));
                vec.add(res.getString(2));
                vec.add(res.getString(3));
                vec.add(res.getDate(4).toLocalDate());
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    
    // Numarul de facilitati si media costului corespunzator acestora pentru fiecare camera din luna aprilie,
    // ordonate crescator dupa numarul camerei
    public List<Vector<Object>> interogareS3(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT C.NumarCamera, COUNT(F.Cod), AVG(F.CostExtra) "
                + "FROM facilitati AS F, camere AS C, cerericazare AS CC, facilitaticamera AS FC "
                + "WHERE C.CodCerere=CC.CodCerere AND C.NumarCamera=FC.NumarCamera AND FC.IDFacilCam=F.IDFacilcam AND MONTH(CC.Checkin)=4 "
                + "GROUP BY C.NumarCamera "
                + "ORDER BY C.NumarCamera ASC";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getInt(1));
                vec.add(res.getInt(2));
                vec.add(res.getDouble(3));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Determinati pentru fiecare cerere, ordonate crescator dupa data de checkin
    // numarul de persoane minore de sex masculin, nascute dupa anul 2007
    public List<Vector<Object>> interogareS4(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cc.Checkin, COUNT(P.CNP) "
                + "FROM cerericazare AS Cc, persoane AS P, camere AS Ca "
                + "WHERE P.CodCerere=Cc.CodCerere AND P.NumarCamera=Ca.NumarCamera AND Ca.CodCerere=Cc.CodCerere AND P.Sex LIKE 'M' "
                + " AND (2019-YEAR(P.DataNasterii))<18 AND YEAR(P.DataNasterii)>=2007 "
                + "ORDER BY Cc.Checkin";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(2);
                vec.add(res.getDate(1).toLocalDate());
                vec.add(res.getInt(2));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Determinati data de checkin, checkout si numarul camerei pentru camerele la care
    // plata s-a realizat cu cardul si la care s-au dorit cel putin 2 mese incluse, fara 
    // a avea alte facilitati
    public List<Vector<Object>> interogareS5(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Ca.NumarCamera, Cc.Checkin, Cc.Checkout "
                + "FROM cerericazare AS Cc, camere AS Ca, facilitaticamera AS Fc, facilitati AS F "
                + "WHERE Cc.CodCerere=Ca.CodCerere AND Ca.IDFacilCam=Fc.IDFacilCam AND Fc.IDFacilCam=F.IDFacilCam AND "
                + "(F.Denumire LIKE 'doua mese incluse' OR F.Denumire LIKE 'trei mese incluse') AND Cc.MetodaPlata LIKE 'card' "
                + "GROUP BY Ca.NumarCamera "
                + "ORDER BY Cc.CostTotal ASC";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getInt(1));
                vec.add(res.getDate(2).toLocalDate());
                vec.add(res.getDate(3).toLocalDate());
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
    
    // Determinati numele, prenumele si semnatura clientilor care au depus o cerere de cazare singuri,
    // pentru care costul facilitatilor este de cel putin 30 si care au dorit doar 2 sau 3 facilitati
    public List<Vector<Object>> interogareS6(){
        List<Vector<Object>> Rez = new LinkedList<>();
        String cmmd = "SELECT Cl.Nume, Cl.Prenume, Cl.Semnatura "
                + "FROM clienti AS Cl,camere AS Ca, facilitaticamera AS Fc, facilitati AS F "
                + "WHERE Cl.NumarCamera=Ca.NumarCamera AND Ca.NrPersoane=1 AND Ca.NumarCamera=Fc.NumarCamera AND Fc.IDFacilCam=F.IDFacilCam "
                + "GROUP BY F.IDFacilCam "
                + "HAVING (COUNT(F.IDFacilCam)=2 OR COUNT(F.IDFacilCam)=3) AND SUM(F.CostExtra)>=30 ";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Vector<Object> vec = new Vector(3);
                vec.add(res.getString(1));
                vec.add(res.getString(2));
                vec.add(res.getString(3));
                
                Rez.add(vec);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return Rez;
    }
}

