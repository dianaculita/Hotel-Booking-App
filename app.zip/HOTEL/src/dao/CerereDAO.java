package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import models.CerereCazare;

public class CerereDAO {
    private Connection conex;
    public CerereDAO(){
       String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addCerere(int nrp, int nrc, int cost, String det, String plata, LocalDate cin, LocalDate cout, String cnp){
        String cmmd = "INSERT INTO cerericazare VALUES(NULL,?,?,?,?,?,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){       
            java.sql.Date dIn = java.sql.Date.valueOf(cin);
            java.sql.Date dOut = java.sql.Date.valueOf(cout);
            
            ps.setInt(1, nrp);
            ps.setInt(2, cost);
            ps.setDate(3, dIn);
            ps.setDate(4, dOut);
            ps.setString(5, det);
            ps.setString(6, plata);
            ps.setInt(7, nrc);
            ps.setString(8, cnp);
            
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public int getLastCerereCod(){
        String cmmd = "SELECT CodCerere FROM cerericazare WHERE CodCerere=(SELECT MAX(CodCerere) FROM cerericazare);";
        List<Integer> coduri = new LinkedList<>();
        int cod = 0;
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                cod = res.getInt("CodCerere");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return cod;
    }
    
    public List<CerereCazare> getCereri(){
        List<CerereCazare> cereri = new LinkedList<>();
        
        String cmmd = "SELECT * FROM CereriCazare";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                CerereCazare c = new CerereCazare();
                c.setCod(res.getInt("CodCerere"));
                c.setNrPersoane(res.getInt("NumarPersoane"));
                c.setCostTotal(res.getInt("CostTotal"));
                c.setCheckin(res.getDate("Checkin").toLocalDate());
                c.setCheckout(res.getDate("Checkout").toLocalDate());
                c.setAlteDetalii(res.getString("AlteDetalii"));
                c.setMetodaPlata(res.getString("MetodaPlata"));
                c.setNrCamere(res.getInt("NumarCamere"));
                
                cereri.add(c);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return cereri;
    }
    
    public void deleteAll(){
        String cmmd = "DELETE FROM cerericazare";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
