package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import models.AsigurareMedicala;

public class AsigurareDAO {
    private Connection conex;
    public AsigurareDAO(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addAsigurare(String n, String pr, LocalDate data, LocalDate val, String clauze, String cnp){
        String cmmd = "INSERT INTO asigurari VALUES(NULL,?,?,?,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            java.sql.Date d = java.sql.Date.valueOf(data);
            java.sql.Date valab = java.sql.Date.valueOf(val);
            
            ps.setString(1, n);
            ps.setString(2, pr);
            ps.setString(3, cnp);
            ps.setDate(4, d);
            ps.setDate(5, valab);
            ps.setString(6, clauze);
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deleteAll(){
        String cmmd = "DELETE FROM asigurari";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public int getLastCodAsigurare(){
        String cmmd = "SELECT CodAsigurare FROM asigurari WHERE CodAsigurare=(SELECT MAX(CodAsigurare) FROM asigurari);";
        List<Integer> coduri = new LinkedList<>();
        
        int cod = 0;
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                cod = res.getInt("CodAsigurare");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return cod;
    }
    
    public List<AsigurareMedicala> getAsigurari(){
        List<AsigurareMedicala> asigs = new LinkedList<>();
        String cmmd = "SELECT * FROM asigurari";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                AsigurareMedicala a = new AsigurareMedicala();
                a.setCod(res.getInt("CodAsigurare"));
                a.setNume(res.getString("Nume"));
                a.setPrenume(res.getString("Prenume"));
                a.setDataEliberarii(res.getDate("DataEliberarii").toLocalDate());
                a.setValabilitate(res.getDate("Valabilitate").toLocalDate());
                a.setClauze(res.getString("Clauze"));
                a.setCnp(res.getString("CNP"));
                
                asigs.add(a);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return asigs;
    } 
}
