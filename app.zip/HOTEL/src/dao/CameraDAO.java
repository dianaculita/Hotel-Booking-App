package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import models.Camera;

public class CameraDAO {
    private Connection conex;
    public CameraDAO(){
       String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addCamera(String tip, int pret, int codcerere, int nrpers, int idfaccam){
        String cmmd = "INSERT INTO camere VALUES(NULL,?,?,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.setString(1, tip);
            ps.setInt(2, nrpers);
            ps.setInt(3, codcerere);
            ps.setInt(4, pret);
            ps.setInt(5, idfaccam);
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deleteAll(){
        String cmmd = "DELETE FROM camere";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public int getLastRoomNr(){
        String cmmd = "SELECT NumarCamera FROM camere WHERE NumarCamera=(SELECT MAX(NumarCamera) FROM camere);";
        List<Integer> numere = new LinkedList<>();
        
        int nr = 0;
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                nr = res.getInt("NumarCamera");
                numere.add(nr);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return nr;   
    }
    
    public void updateID(int id){
        String cmmd = "UPDATE camere SET IDFacilCam=? WHERE IDFacilCam=0";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.setInt(1, id);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void updateCost(int cost){
        String cmmd = "UPDATE cerericazare SET CostTotal=? WHERE CostTotal=1";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.setInt(1, cost);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void updateNrCameraClient(int nr){
        String cmmd = "UPDATE clienti SET NumarCamera=? WHERE NumarCamera=1";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.setInt(1, nr);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void updateNrCameraPers(int nr){
        String cmmd = "UPDATE persoane SET NumarCamera=? WHERE NumarCamera=1";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.setInt(1, nr);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<Camera> getCamere(){
        List<Camera> camere = new LinkedList<>();
        String cmmd = "SELECT * FROM camere";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Camera c = new Camera();
                c.setNr(res.getInt("NumarCamera"));
                c.setTip(res.getString("Tip"));
                c.setNrPers(res.getInt("NrPersoane"));
                c.setCodCerere(res.getInt("CodCerere"));
                c.setPret(res.getInt("Pret"));
                
                camere.add(c);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        return camere;
    }
}
