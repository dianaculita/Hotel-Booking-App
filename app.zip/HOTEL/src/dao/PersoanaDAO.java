package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import models.Persoana;

public class PersoanaDAO {
    private Connection conex;
    public PersoanaDAO(){
        String url = "jdbc:mysql://localhost/hotelerhart";
        String user = "root";
        String psswd = "";
        
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            System.out.println("trying connection ... ");
            conex = DriverManager.getConnection(url, user, psswd);
            Statement s = conex.createStatement();
            System.out.println("OK ");
            
        }catch(Exception e){
            System.out.println("connection failed with error ! ");
            e.printStackTrace();
        }
    }
    
    public void addPersoana(String n, String p, String cnp, LocalDate datan, String sex, int nrcam, int codasig, int codcerere){
        String cmmd = "INSERT INTO persoane VALUES(?,?,?,?,?,?,?,?)";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            java.sql.Date d = java.sql.Date.valueOf(datan);
            
            ps.setString(1, cnp);
            ps.setString(2, n);
            ps.setString(3, p);
            ps.setDate(4, d);
            ps.setString(5, sex);
            ps.setInt(6, codasig);
            ps.setInt(7, nrcam);
            ps.setInt(8, codcerere);
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    
    public void deleteAll(){
        String cmmd = "DELETE FROM persoane";
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public List<Persoana> getPersoane(){
        List<Persoana> persoane = new LinkedList<>();
        String cmmd = "SELECT * FROM persoane";
        
        try(PreparedStatement ps = conex.prepareStatement(cmmd)){
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Persoana p = new Persoana();
                p.setNume(res.getString("Nume"));
                p.setPrenume(res.getString("Prenume"));
                p.setCNP(res.getString("CNP"));
                p.setDataNasterii(res.getDate("DataNasterii").toLocalDate());
                p.setSex(res.getString("Sex").charAt(0));
                p.setNrCamera(res.getInt("NumarCamera"));
                p.setCodCerere(res.getInt("CodCerere"));
                
                
                persoane.add(p);
                        
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return persoane;
    }
    
}
